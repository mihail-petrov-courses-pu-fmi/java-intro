import java.util.Scanner;

public class Application {

    static Scanner scannerInput = new Scanner(System.in);

    static final int TILE      = 0;

    static final int W_PAWN    = 1;
    static final int W_ROOK    = 2;
    static final int W_BISHOP  = 3;
    static final int W_KNIGHT  = 4;
    static final int W_QUEEN   = 5;
    static final int W_KING    = 6;

    static final int B_PAWN    = -1;
    static final int B_ROOK    = -2;
    static final int B_BISHOP  = -3;
    static final int B_KNIGHT  = -4;
    static final int B_QUEEN   = -5;
    static final int B_KING    = -6;

    static int[][] gameBoard = {
            {W_ROOK, W_KNIGHT, W_BISHOP, W_QUEEN, W_KING, W_BISHOP, W_KNIGHT, W_ROOK},
            {W_PAWN, W_PAWN, W_PAWN, W_PAWN, W_PAWN, W_PAWN, W_PAWN, W_PAWN},
            {TILE, TILE, TILE, TILE, TILE, TILE, TILE, TILE},
            {TILE, TILE, TILE, TILE, TILE, TILE, TILE, TILE},
            {TILE, TILE, TILE, TILE, TILE, TILE, TILE, TILE},
            {TILE, TILE, TILE, TILE, TILE, TILE, TILE, TILE},
            {B_PAWN, B_PAWN, B_PAWN, B_PAWN, B_PAWN, B_PAWN, B_PAWN, B_PAWN},
            {B_ROOK, B_KNIGHT, B_BISHOP, B_QUEEN, B_KING, B_BISHOP, B_KNIGHT, B_ROOK}
    };

    public static void render() {
        // Вариант 1
//        for(int row = 0; row < gameBoard.length; row++) {
//            int[] processableRow = gameBoard[row];
//
//            for(int col = 0; col < processableRow.length; col++) {
//                int element = processableRow[col];
//                System.out.print(" " + getPieceSign(element) + " ");
//            }
//
//            System.out.println();
//        }

        // Вариант 2
        for(int[] processableRow  : gameBoard) {
            for(int element : processableRow) {
                System.out.print(" " + getPieceSign(element) + " ");
            }
            System.out.println();
        }
    }

    public static String getPieceSign(int pieceId) {

// Вариант 2
        if(pieceId == 0) return "X";

        String colorCode = (pieceId > 0) ? "w" : "b";
        int index        = (pieceId > 0) ? pieceId : pieceId * -1;
        String[] signMap = {"X", "P", "R","B", "K", "Q", "Kn" };
        return colorCode + signMap[index];

// Вариант 1
//        if(pieceId == W_PAWN    ) return "wP";
//        if(pieceId == W_ROOK    ) return "wR";
//        if(pieceId == W_BISHOP  ) return "wB";
//        if(pieceId == W_KNIGHT  ) return "wK";
//        if(pieceId == W_QUEEN   ) return "wQ";
//        if(pieceId == W_KING    ) return "wKn";
//        if(pieceId == B_PAWN    ) return "bP";
//        if(pieceId == B_ROOK    ) return "bR";
//        if(pieceId == B_BISHOP  ) return "bB";
//        if(pieceId == B_KNIGHT  ) return "bK";
//        if(pieceId == B_QUEEN   ) return "bQ";
//        if(pieceId == B_KING    ) return "bKn";

//        return "X";
    }

    public static void move(int fromRow, int fromCol, int toRow, int toCol) {

        int pieceId                 = gameBoard[fromRow][fromCol];
        gameBoard[fromRow][fromCol] = TILE;
        gameBoard[toRow][toCol]     = pieceId;
    }

    public static void main(String[] args) {

        while(true) {
            render();

            System.out.print("Изберете фигъра на ред - ");
            int fromRow = scannerInput.nextInt();
            System.out.print("Изберете фигъра на колона - ");
            int fromCol = scannerInput.nextInt();

            System.out.print("Поставете фигъра на ред - ");
            int toRow = scannerInput.nextInt();
            System.out.print("Поставете фигъра на колона - ");
            int toCol = scannerInput.nextInt();
            move(fromRow, fromCol, toRow, toCol);
        }
    }
}