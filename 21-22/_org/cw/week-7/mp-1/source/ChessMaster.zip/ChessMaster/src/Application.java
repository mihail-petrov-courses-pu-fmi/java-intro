public class Application {

    static final int TILE      = 0;
    static final int W_PAWN    = 1;
    static final int W_ROOK    = 2;
    static final int W_BISHOP  = 3;
    static final int W_KNIGHT  = 4;
    static final int W_QUEEN   = 5;
    static final int W_KING    = 6;
    static final int B_PAWN    = -1;
    static final int B_ROOK    = -2;
    static final int B_BISHOP  = -3;
    static final int B_KNIGHT  = -4;
    static final int B_QUEEN   = -5;
    static final int B_KING    = -6;

    public static String getPieceSign(int pieceId) {

// Вариант 1
//        if(pieceId == W_PAWN    ) return "wP";
//        if(pieceId == W_ROOK    ) return "wR";
//        if(pieceId == W_BISHOP  ) return "wB";
//        if(pieceId == W_KNIGHT  ) return "wK";
//        if(pieceId == W_QUEEN   ) return "wQ";
//        if(pieceId == W_KING    ) return "wKn";
//        if(pieceId == B_PAWN    ) return "bP";
//        if(pieceId == B_ROOK    ) return "bR";
//        if(pieceId == B_BISHOP  ) return "bB";
//        if(pieceId == B_KNIGHT  ) return "bK";
//        if(pieceId == B_QUEEN   ) return "bQ";
//        if(pieceId == B_KING    ) return "bKn";
//
//        return ".";

// Вариант 2
//        int index = pieceId * -1;
//        String sign = "X";
//        String color = "";
//        if(pieceId < 0) {
//            color = "b";
//        }
//        else if(pieceId > 0) {
//            color = "w";
//        }
//
//        if(index == 1) return color + "P";
//        if(index == 2) return color + "R";
//        if(index == 3) return color + "B";
//        if(index == 4) return color + "K";
//        if(index == 5) return color + "Q";
//        if(index == 6) return color + "Kn";
//
//        return sign;

        if(pieceId == 0) return "X";

        String color = (pieceId > 0) ? "w" : "b";
        int index    = (pieceId > 0) ? pieceId : (pieceId * -1);

        String[] pieceMap = {"X", "P", "R", "B", "K", "Q", "Kn"};
        return color + pieceMap[index];
    }

    public static void main(String[] args) {

        int[][] gameBoard = {
                {W_ROOK, W_KNIGHT, W_BISHOP, W_QUEEN, W_KING, W_BISHOP, W_KNIGHT, W_ROOK },
                {W_PAWN, W_PAWN, W_PAWN, W_PAWN, W_PAWN, W_PAWN, W_PAWN, W_PAWN },
                {TILE, TILE, TILE, TILE, TILE, TILE, TILE, TILE },
                {TILE, TILE, TILE, TILE, TILE, TILE, TILE, TILE },
                {TILE, TILE, TILE, TILE, TILE, TILE, TILE, TILE },
                {TILE, TILE, TILE, TILE, TILE, TILE, TILE, TILE },
                {B_PAWN, B_PAWN, B_PAWN, B_PAWN, B_PAWN, B_PAWN, B_PAWN, B_PAWN },
                {B_ROOK, B_KNIGHT, B_BISHOP, B_QUEEN, B_KING, B_BISHOP, B_KNIGHT, B_ROOK },
        };

// Вариант 1
//        for(int row = 0; row < gameBoard.length; row++) {
//            int[] processableRow = gameBoard[row];
//
//            for(int col = 0; col < processableRow.length; col++) {
//                String pieceSign =  getPieceSign(processableRow[col]);
//                System.out.print(" " + pieceSign + " ");
//            }
//
//            System.out.println();
//        }

        for(int[] processableRow : gameBoard) {
            for(int element : processableRow) {
                String pieceSign =  getPieceSign(element);
                System.out.print(" " + pieceSign + " ");
            }
            System.out.println();
        }
    }
}
